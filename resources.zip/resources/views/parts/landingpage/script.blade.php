     <!-- Jquery and Js Plugins -->
    <script type="text/javascript" src="{{asset('assets\extra-pages\landingpage\assets\js\jquery-2.1.1.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\extra-pages\landingpage\assets\js\bootstrap.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\extra-pages\landingpage\assets\js\plugins.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\extra-pages\landingpage\assets\js\menu.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\extra-pages\landingpage\assets\js\custom.js')}}"></script>
    {{-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script> --}}
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>