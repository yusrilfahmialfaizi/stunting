@include('parts.landingpage.header')
@yield('content')
@include('parts.landingpage.footer')