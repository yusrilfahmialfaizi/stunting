<!DOCTYPE html>
<html lang="en">

@include('parts.landingpage.head')
<body>