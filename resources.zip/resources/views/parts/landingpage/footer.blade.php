     @include('parts.landingpage.script')     
</body>

</html>