<!DOCTYPE html>
<html lang="en">
     @include('parts.login.head')
     @include('parts.login.body')