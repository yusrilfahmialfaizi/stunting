<!-- Required Jquery -->
<script type="text/javascript" src="{{asset('assets\bower_components\jquery\js\jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets\bower_components\jquery-ui\js\jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{asset('assets\bower_components\popper.js\js\popper.min')}}.js"></script>
<script type="text/javascript" src="{{asset('assets\bower_components\bootstrap\js\bootstrap.min.js')}}"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="{{asset('assets\bower_components\jquery-slimscroll\js\jquery.slimscroll.js')}}">
</script>
<!-- modernizr js -->
<script type="text/javascript" src="{{asset('assets\bower_components\modernizr\js\modernizr.js')}}"></script>
<script type="text/javascript" src="{{asset('assets\bower_components\modernizr\js\css-scrollbars.js')}}"></script>
<!-- i18next.min.js -->
<script type="text/javascript" src="{{asset('assets\bower_components\i18next\js\i18next.min.js')}}"></script>
<script type="text/javascript"
    src="{{asset('assets\bower_components\i18next-xhr-backend\js\i18nextXHRBackend.min.js')}}"></script>
<script type="text/javascript"
    src="{{asset('assets\bower_components\i18next-browser-languagedetector\js\i18nextBrowserLanguageDetector.min.js')}}">
</script>
<script type="text/javascript" src="{{asset('assets\bower_components\jquery-i18next\js\jquery-i18next.min.js')}}">
</script>
<script type="text/javascript" src="{{asset('assets\assets\js\common-pages.js')}}"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
</script>