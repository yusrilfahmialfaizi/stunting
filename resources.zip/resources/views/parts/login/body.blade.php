<body class="fix-menu">
    <!-- Pre-loader start -->
    @include('parts.login.pre_loader')
    <!-- Pre-loader end -->