<!DOCTYPE html>
<html lang="en">
@include('parts.main.admin.head')

@include('parts.main.admin.pre_loader_admin')

