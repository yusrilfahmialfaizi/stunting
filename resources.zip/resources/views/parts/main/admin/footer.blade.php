               </div>
            </div>
        </div>
    </div>
@include('parts.main.admin.script')
</body>

</html>