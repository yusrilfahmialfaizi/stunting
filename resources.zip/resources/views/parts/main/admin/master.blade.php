@include('parts.main.admin.header')
@yield('content')
@include('parts.main.admin.footer')