<!-- Required Jquery -->
    {{-- <script data-cfasync="false" src="..\..\..\cdn-cgi\scripts\5c5dd728\cloudflare-static\email-decode.min.js')}}"></script> --}}
    <script type="text/javascript" src="{{asset('assets\bower_components\jquery\js\jquery.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\bower_components\jquery-ui\js\jquery-ui.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\bower_components\popper.js\js\popper.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\bower_components\bootstrap\js\bootstrap.min.js')}}"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="{{asset('assets\bower_components\jquery-slimscroll\js\jquery.slimscroll.js')}}"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="{{asset('assets\bower_components\modernizr\js\modernizr.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\bower_components\modernizr\js\css-scrollbars.js')}}"></script>
    <!-- Chart js -->
    <script type="text/javascript" src="{{asset('assets\bower_components\chart.js\js\Chart.js')}}"></script>
    <!-- amchart js -->
    <script type="text/javascript" src="{{asset('assets\assets\pages\dashboard\amchart\js\amcharts.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\assets\pages\dashboard\amchart\js\serial.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\assets\pages\dashboard\amchart\js\light.js')}}"></script>
    <!-- owl carousel 2 js -->
    <script type="text/javascript" src="{{asset('assets\bower_components/owl.carousel/js/owl.carousel.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\assets/js/owl-custom.js')}}"></script>
    <!-- swiper js -->
    <script type="text/javascript" src="{{asset('assets\bower_components/swiper/js/swiper.min.js')}}"></script>
    <!-- data-table js -->
    <script src="{{asset('assets\bower_components\datatables.net\js\jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets\bower_components\datatables.net-buttons\js\dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets\assets\pages\data-table\js\jszip.min.js')}}"></script>
    <script src="{{asset('assets\assets\pages\data-table\js\pdfmake.min.js')}}"></script>
    <script src="{{asset('assets\assets\pages\data-table\js\vfs_fonts.js')}}"></script>
    <script src="{{asset('assets\bower_components\datatables.net-buttons\js\buttons.print.min.js')}}"></script>
    <script src="{{asset('assets\bower_components\datatables.net-buttons\js\buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets\bower_components\datatables.net-bs4\js\dataTables.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets\bower_components\datatables.net-responsive\js\dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets\bower_components\datatables.net-responsive-bs4\js\responsive.bootstrap4.min.js')}}">
    </script>
    <script src="{{asset('assets\assets\pages\data-table\extensions\buttons\js\extension-btns-custom.js')}}"></script>
    <script src="{{asset('assets\assets\pages\data-table\js\data-table-custom.js')}}"></script>
    <!-- sweet alert js -->
    <script type="text/javascript" src="{{asset('assets/assets/js/sweetalert.js')}}"></script>
    <!-- sweet alert modal.js intialize js -->
    <!-- modalEffects js nifty modal window effects -->
    <script type="text/javascript" src="{{asset('assets/assets/js/modalEffects.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets/assets/js/classie.js')}}"></script>
    <!-- Select 2 js -->
    <script type="text/javascript" src="{{asset('assets\bower_components/select2/js/select2.full.min.js')}}"></script>
    <!-- Multiselect js -->
    <script type="text/javascript" src="{{asset('assets\bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\bower_components/multiselect/js/jquery.multi-select.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\assets/js/jquery.quicksearch.js')}}"></script>
    <!-- Custom js -->
    <script type="text/javascript" src="{{asset('assets\assets\pages\dashboard\custom-dashboard.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\assets/pages/advance-elements/select2-custom.js')}}"></script>
    <script src="{{asset('assets\assets\js\pcoded.min.js')}}"></script>
    {{-- <script src="{{asset('assets\assets/js/menu/menu-hori-fixed.js')}}"></script> --}}
    <script src="{{asset('assets\assets\js\horizontal-layout.min.js')}}"></script>
    <script src="{{asset('assets\assets\js\jquery.mCustomScrollbar.concat.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('assets\assets\js\script.js')}}"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>